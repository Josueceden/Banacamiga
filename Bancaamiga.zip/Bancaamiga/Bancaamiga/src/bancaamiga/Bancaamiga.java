/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bancaamiga;
import java.io.*;
import java.util.Random;
import java.util.Scanner;


/**
 *
 * @author USUARIO
 */
public class Bancaamiga {
    
    public static void main(String[] args) throws IOException {
        Bank inicio = new Bank();
        inicio.Transacciones();
    }
    
}

class nodo{
    String nombre;
    int edad, depos, retir,act,pag,consult;
    double cuenta;
    nodo siguiente;
    nodo(String nombre, int edad, double cuenta,int depos, int retir,int act,int pag,int consult){
        this.nombre = nombre;
        this.edad = edad;
        this.act = act;
        this.depos = depos;
        this.retir = retir;
        this.consult = consult;
        this.pag = pag;
        this.cuenta = cuenta;
        this.siguiente=null;
    }
}

class pila {
    nodo Top;
    void push(String name, int edad, double cuenta,int depos, int retir,int act,int pag,int consult){ // 1
            
        this.Top = new nodo(name, edad, cuenta,depos, retir, act, pag,consult); 
            
        
    }
    boolean isEmpty(){
        return this.Top == null; 
    }
     nodo pop(){
        nodo valor_temp;
        if (this.isEmpty()){
            System.out.println("Pila Vacia");
            return null;
        }else{
            valor_temp = this.Top;
            this.Top = this.Top.siguiente;
            valor_temp.siguiente = null;
            return valor_temp;
        }
    }
     nodo peek(){
        if (this.isEmpty()) {
            System.out.println("Pila Vacia");
            return null;
        }else{
            return new nodo(this.Top.nombre,this.Top. edad, this.Top.cuenta,this.Top.depos, this.Top.retir, this.Top.act, this.Top.pag,this.Top.consult);
        }
    }
     String mostrarPila(){
        nodo temporal = null;
        String datos = "TOP ";
        while (!this.isEmpty()){
            datos += " -> " + this.peek();
            if (temporal == null) {
                temporal = new nodo(this.pop().nombre,this.pop().edad,this.pop().cuenta,this.pop().retir, this.pop().depos, this.pop().act,this.pop().pag,this.pop().consult);
            }else{
                temporal = new nodo(this.pop().nombre,this.pop().edad,this.pop().cuenta,this.pop().retir, this.pop().depos, this.pop().act,this.pop().pag,this.pop().consult);
            }
        }
        while (temporal != null){
            this.push(temporal.nombre,temporal.edad,temporal.cuenta,temporal.depos,temporal.retir,temporal.act,temporal.pag,temporal.consult);
            temporal = temporal.siguiente;
        }
        return datos;
    }
}

class Bank{
    private cliente espera;
    private pila atendiendo;
    
    int acciones,horas,n;
    double min;
    public Bank(){
        espera = new cliente();
        atendiendo = new pila();
        acciones = 0;
        min = 0;
        horas = 8;
    }
    public void Transacciones() throws IOException{
        
        Scanner scanner = new Scanner(System.in);
        Random rd = new Random();
        try (FileReader fr = new FileReader("D:\\Clientes.in.txt")) {
         BufferedReader br = new BufferedReader(fr);
         
         String linea;
     
         while((linea=br.readLine())!=null){
             int edad  = rd.nextInt(63)+18;
            espera.encolar(linea,edad, 500, 0, 0,0,0,0);
            
            }
            
        }
        nodo cliente = espera.espera();
        atendiendo.push(cliente.nombre, cliente.edad, cliente.cuenta, cliente.act, cliente.consult, cliente.depos, cliente.retir, cliente.act);
        while(!atendiendo.isEmpty()){
            if(horas==15 && min>=30){
                break;
            }
            System.out.println(""+horas+":"+min);
            System.out.println("Presione 1 para hacer un retiero");
            System.out.println("Presione 2 para hacer un deposito");
            System.out.println("Presiene 3 para hacer una consulta");
            System.out.println("Presione 4 para hacer actualizacion de libreta");
            System.out.println("Presione 5 para hacer pago de servicio");
            System.out.println("Presione 6 para terminar");
            int caracter = scanner.nextInt();
            switch(caracter){
                case 1 -> {
                    atendiendo.Top.retir++;
                    System.out.println("Monto a retirar:");
                    int retirar = scanner.nextInt();
                    if (retirar<atendiendo.Top.cuenta){
                    atendiendo.Top.cuenta=atendiendo.Top.cuenta-retirar;
                    System.out.println("Retiro exitoso");
                    
                    } 
                    else{
                        System.out.println("Fondos insuficientes");
                    }
                    min=min+4;
                    if(min>=60){
                        horas++;
                        min=0;
                    }
                    acciones++;
                    
                }
                case 2 -> {
                    atendiendo.Top.depos++;
                    System.out.println("Monto a depositar:");
                    int depositar = scanner.nextInt();
                    atendiendo.Top.cuenta=atendiendo.Top.cuenta+depositar;
                    System.out.println("Deposito exitoso");
                    acciones++;
                    min=min+3;
                    if(min>=60){
                        horas++;
                        min=0;
                    }
                }
                case 3 -> {
                   atendiendo.Top.consult++;
                   System.out.println("Se ha hecho los siguientes movimientos:");
                   System.out.println("Depositos: "+atendiendo.Top.depos);
                   System.out.println("Retiro: "+atendiendo.Top.retir);
                   System.out.println("Consultas: "+atendiendo.Top.consult);
                   System.out.println("Actualizacion de libreta: "+atendiendo.Top.act);
                   System.out.println("Pago de servicio: "+atendiendo.Top.pag);
                   acciones++;
                   min=min+1.5;
                    if(min>=60){
                        horas++;
                        min=0;
                    }
                }
                case 4 -> {
                    atendiendo.Top.act++;
                    System.out.println("Nombre: "+atendiendo.Top.nombre);
                    System.out.println("Edad: "+atendiendo.Top.edad);
                    System.out.println("Cuenta: "+atendiendo.Top.cuenta);
                    acciones++; 
                    min=min+5;
                    if(min>=60){
                        horas++;
                        min=0;
                    }
                  
                }
                case 5 -> {
                    atendiendo.Top.pag++;
                    atendiendo.Top.cuenta = atendiendo.Top.cuenta-atendiendo.Top.cuenta*0.05;
                    System.out.println("Se ha hecho un pago de 0.05% de su cuenta por los servicios de Bancamiga");
                    System.out.println("Siendo un costo total de: "+atendiendo.Top.cuenta*0.05+"Bs");
                    acciones++;
                    min=min+2;
                    if(min>=60){
                        horas++;
                        min=0;
                    }
                }
                case 6 -> {
                    FileWriter escribi = new FileWriter("D:\\taquilla.log.txt", true);
                    BufferedWriter escribi2 = new BufferedWriter(escribi);
                    escribi2.write("Nombre: "+atendiendo.Top.nombre+" ");
                    escribi2.write("Edad: "+atendiendo.Top.edad+" ");
                    escribi2.write("Depositos: "+atendiendo.Top.depos+" ");
                    escribi2.write("Retiro: "+atendiendo.Top.retir+" ");
                    escribi2.write("Consultas: "+atendiendo.Top.consult+" ");
                    escribi2.write("Actualizacion de libreta: "+atendiendo.Top.act+" ");
                    escribi2.write("Pago de servicio: "+atendiendo.Top.pag+" ");
                    escribi2.newLine();
                    escribi2.newLine();
                    escribi2.close();

                    if (!atendiendo.isEmpty()) {
                    
                    nodo siguienteCliente = espera.espera();
                    atendiendo.push(siguienteCliente.nombre, siguienteCliente.edad, siguienteCliente.cuenta, siguienteCliente.act, siguienteCliente.consult, siguienteCliente.depos, siguienteCliente.retir, siguienteCliente.act);
                    
                    } 
                    else {
                        
                    }
                   
                }
                default -> {
                    System.out.println("Opcion disponible");  
                    acciones++;
                }
               

            }
            if (acciones==5){
              nodo siguienteCliente = espera.espera();
              atendiendo.push(siguienteCliente.nombre, siguienteCliente.edad, siguienteCliente.cuenta, siguienteCliente.act, siguienteCliente.consult, siguienteCliente.depos, siguienteCliente.retir, siguienteCliente.act);
              acciones = 0;        
            }
        
            scanner.nextLine();
            


        }
    }
        
}

class cliente{
    nodo front, tail;
    int valorPreferencial = 60;
    int cantPreferencia = 4;
    nodo Atendiendo;
    void encolar(String nombre, int edad, double cuenta, int depos, int retir,int act,int pag,int consult){
        
        nodo nuevo = new nodo(nombre, edad, cuenta, depos, retir, act, pag, consult);

        if (edad >= valorPreferencial) {
            if (Atendiendo == null) {
                Atendiendo = nuevo;
                front = tail = Atendiendo;
            } else {
                nuevo.siguiente = Atendiendo;
                Atendiendo = nuevo;
                front = nuevo;
            }
        } else {
            if (front == null) {
                front = tail = nuevo;
            } else {
                nodo temp = front;
                int count = 0;
                while (temp != null && count < cantPreferencia) {
                    if (temp.edad < valorPreferencial) {
                        count++;
                    }
                    temp = temp.siguiente;
                }

                if (temp != null) {
                    nuevo.siguiente = temp.siguiente;
                    temp.siguiente = nuevo;
                } else {
                    tail.siguiente = nuevo;
                    tail = nuevo;
                }
            }
        }
    }
    void encolar(nodo nuevo){
        nuevo.siguiente = null;
        if (front == null){
            front = tail = nuevo;
        }else{
            tail.siguiente = nuevo;
            tail = tail.siguiente;
        }
    }
    
    boolean isEmpty(){
        return front == null; 
     
    }
    public nodo espera() {
        if (isEmpty()) {
            return null;
        }
         nodo temp = front;
        front = front.siguiente;
        if (front == null) {
            tail = null;
        }

        return temp;
    
    }
}